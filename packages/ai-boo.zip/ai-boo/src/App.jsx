import React from 'react';
import VoiceAssistant from './VoiceAssistant';

function App() {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', maxWidth: '800px', margin: '0 auto', padding: '40px 20px' }}>
      <header style={{ borderBottom: '2px solid #eaeaea', paddingBottom: '20px', marginBottom: '20px' }}>
        <h1 style={{ color: '#333', fontSize: '32px', margin: '0 0 10px 0' }}>AI Boo Dashboard</h1>
        <p style={{ color: '#666', margin: 0 }}>Personalized AI Avatar & Subscription Platform</p>
      </header>
      
      <main>
        {/* Render your interactive voice element */}
        <VoiceAssistant />
        
        <section style={{ marginTop: '40px', padding: '20px', border: '1px dashed #bbb', borderRadius: '6px' }}>
          <h4>💡 Script Tricks:</h4>
          <ul>
            <li>Say <strong>"Hello"</strong> to test a warm greeting response.</li>
            <li>Say <strong>"Status"</strong> to trigger a system diagnostic health report.</li>
            <li>Say <strong>"Subscription"</strong> to query monetization details.</li>
          </ul>
        </section>
      </main>
    </div>
  );
}

export default App;
