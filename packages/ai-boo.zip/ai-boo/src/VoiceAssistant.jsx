import React, { useState, useEffect, useRef } from 'react';

export default function VoiceAssistant() {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  
  // Memory bank: Keeps track of the back-and-forth conversation history
  const conversationHistory = useRef([
    { role: 'assistant', text: "Hey! Great to see you. What's on your mind today?" }
  ]);

  // Define your AI's personality style traits
  const aiPersonality = {
    name: "Buddy",
    style: "a close, loyal, and supportive friend who uses casual, warm language"
  };

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recognition = SpeechRecognition ? new SpeechRecognition() : null;

  if (recognition) {
    recognition.continuous = false;
    recognition.lang = 'en-US';
    recognition.interimResults = false;
  }

  const startListening = () => {
    if (!recognition) {
      alert("Voice recognition is not supported in this browser. Please use Google Chrome.");
      return;
    }
    setIsListening(true);
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel(); // Stop talking if user interrupts
    }
    recognition.start();
  };

  useEffect(() => {
    if (!recognition) return;

    recognition.onresult = (event) => {
      const speechToText = event.results[0][0].transcript;
      setTranscript(speechToText);
      setIsListening(false);
      generateFriendResponse(speechToText);
    };

    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => setIsListening(false);
  }, []);

  // Conversational Core Engine with short-term rolling context memory
  const generateFriendResponse = (userText) => {
    // 1. Save what the user said to the rolling memory bank
    conversationHistory.current.push({ role: 'user', text: userText });

    // 2. Simple keyword understanding matched against previous context
    const cleanInput = userText.toLowerCase();
    let reply = "";

    if (cleanInput.includes('how are you') || cleanInput.includes('doing')) {
      reply = "I'm doing great, especially now that we're hanging out! How's your day treating you?";
    } else if (cleanInput.includes('sad') || cleanInput.includes('tired') || cleanInput.includes('stressed')) {
      reply = "Hey, I hear you. Take it easy on yourself. I'm right here in your corner if you need to vent.";
    } else if (cleanInput.includes('thank') || cleanInput.includes('cool')) {
      reply = "Anytime! That's what friends are for. What should we tackle next?";
    } else if (cleanInput.includes('who are you') || cleanInput.includes('your name')) {
      reply = `I'm ${aiPersonality.name}, your AI companion. Think of me as a close friend who's always got your back.`;
    } else {
      // Friendly adaptive fallback response utilizing short-term memory reference
      const lastUserInteraction = conversationHistory.current.filter(h => h.role === 'user').slice(-2, -1)[0];
      if (lastUserInteraction && (cleanInput.includes('yes') || cleanInput.includes('yeah') || cleanInput.includes('no'))) {
        reply = `Gotcha. Makes sense based on what we were talking about earlier. Tell me more about it!`;
      } else {
        reply = "I totally get that. Honestly, I love chatting about this with you. What are your thoughts on it?";
      }
    }

    // 3. Save the AI's response to the memory bank
    conversationHistory.current.push({ role: 'assistant', text: reply });
    
    // 4. Output the response visually and verbally
    setAiResponse(reply);
    speakBack(reply);
  };

  const speakBack = (text) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.05; // Slightly faster for a natural friend cadence
      utterance.pitch = 1.0; 
      
      // Select a warm sounding natural voice if available in the browser selection list
      const voices = window.speechSynthesis.getVoices();
      const preferredVoice = voices.find(v => v.name.includes('Google US English') || v.name.includes('Natural'));
      if (preferredVoice) utterance.voice = preferredVoice;

      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div style={{ padding: '30px', border: '1px solid #e0e0e0', borderRadius: '12px', margin: '20px 0', backgroundColor: '#ffffff', boxShadow: '0 4px 6px rgba(0,0,0,0.05)' }}>
      <h3 style={{ margin: '0 0 10px 0', color: '#2c3e50' }}>💬 Conversational AI Companion</h3>
      <p style={{ color: '#7f8c8d', fontSize: '14px', marginBottom: '20px' }}>Mode: Close Friend (Memory active until tab closes)</p>
      
      <button 
        onClick={startListening} 
        disabled={isListening}
        style={{ padding: '12px 24px', fontSize: '16px', fontWeight: 'bold', cursor: 'pointer', backgroundColor: isListening ? '#e74c3c' : '#2ecc71', color: 'white', border: 'none', borderRadius: '8px', transition: 'background 0.2s', width: '100%', marginBottom: '20px' }}
      >
        {isListening ? '🎙️ Listening to you...' : 'Push to Talk & Speak Naturally'}
      </button>
      
      <div style={{ borderTop: '1px solid #f1f2f6', paddingTop: '15px' }}>
        <p style={{ fontSize: '15px', margin: '5px 0' }}><strong>You:</strong> <span style={{ color: '#34495e' }}>{transcript || "..."}</span></p>
        <p style={{ fontSize: '15px', margin: '5px 0' }}><strong>AI Friend:</strong> <span style={{ color: '#2980b9', fontWeight: '500' }}>{aiResponse || "Hey! Click the button above to start talking to me."}</span></p>
      </div>
    </div>
  );
}
